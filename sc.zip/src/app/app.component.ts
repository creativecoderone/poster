import { Component } from "@angular/core";
import { OnDestroy } from "@angular/core";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent  {
  title = "Swan paper";
  caner = false;
  type = "PieChart";
  data = [
    ["Firefox", 45.0],
    ["IE", 26.8],
    ["Chrome", 12.8],
    ["Safari", 8.5],
    ["Opera", 6.2],
    ["Others", 0.7]
  ];
  columnNames = ["Browser", "Percentage"];
  options = {
    colors: ["#e0440e", "#e6693e", "#ec8f6e", "#f3b49f", "#f6c7b6"],
    is3D: true
  };
  loader = false;
  canerIt() {
    this.loader = true;
    setTimeout(() => {
      this.loader = false;
      this.caner = !this.caner;
    }, 1000);
  }
}
