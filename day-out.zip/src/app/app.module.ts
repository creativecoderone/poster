import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { FormsModule } from "@angular/forms";
import { ClipboardModule } from "ngx-clipboard";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { GoogleChartsModule } from "angular-google-charts";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { SugarComponent } from "./sugar/sugar.component";
import { CanComponent } from "./can/can.component";
import { SanitaizerPipe } from "./sanitaizer.pipe";
import { FilterPipeModule } from "ngx-filter-pipe";
import { SampleComponent } from "./sample/sample.component";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { SpeechRecognitionService } from "src/app/services/speech";
import { MugComponent } from "./mug/mug.component";
import { StoreModule } from "@ngrx/store";
import { reducers, metaReducers } from "./reducers";
import { counterReducer } from "./counter.reducer";
import { MyCounterComponent } from "./my-counter/my-counter.component";
import { IntercepterService } from "src/app/int/intercepter.service";
@NgModule({
  declarations: [
    AppComponent,
    SugarComponent,
    CanComponent,
    SanitaizerPipe,
    SampleComponent,
    MugComponent,
    MyCounterComponent
  ],
  imports: [
    BrowserModule,
    GoogleChartsModule,
    AppRoutingModule,
    FilterPipeModule,
    Ng2SearchPipeModule,
    HttpClientModule,
    ClipboardModule,
    FormsModule,
    StoreModule.forRoot({ count: counterReducer })
  ],
  exports: [SanitaizerPipe],
  bootstrap: [AppComponent],
  providers: [
    SpeechRecognitionService,
    { provide: HTTP_INTERCEPTORS, useClass: IntercepterService, multi: true }
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {}
