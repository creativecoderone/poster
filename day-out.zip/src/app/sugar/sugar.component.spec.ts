import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { SugarComponent } from "./sugar.component";
import { FormsModule } from "@angular/forms";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";

describe("SugarComponent", () => {
  let component: SugarComponent;
  let fixture: ComponentFixture<SugarComponent>;

  beforeEach(
    async(() => {
      TestBed.configureTestingModule({
        declarations: [SugarComponent],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
      }).compileComponents();
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(SugarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it("Check renderer", () => {
  //   component.getRender(1);
  //   expect(component).toBe(1);
  // });
});
