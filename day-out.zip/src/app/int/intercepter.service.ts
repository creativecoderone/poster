import { Injectable } from "@angular/core";
import {
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpEvent,
  HttpResponse
} from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable()
export class IntercepterService implements HttpInterceptor {
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    console.log(request.url);
    const storageUser = localStorage.getItem("power");

    // if (storageUser.length > 0) {
    //   console.log(storageUser);
    //   // request = request.clone({
    //   //   headers: request.headers.set("Authorization", "Manojkumar")
    //   // });
    // }
    return next.handle(request);
  }
}
