import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mug',
  templateUrl: './mug.component.html',
  styleUrls: ['./mug.component.scss']
})
export class MugComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
