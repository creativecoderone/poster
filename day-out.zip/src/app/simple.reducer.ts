import { Action } from "@ngrx/store";

export function simpleReducer(state: string = "Hello world", action: Action) {
  console.log(action.type, state);
  switch (action.type) {
    case "ENG":
      return (state = "English");
    case "HIND":
      return (state = "Hindhi");
    default:
      return state;
  }
}
