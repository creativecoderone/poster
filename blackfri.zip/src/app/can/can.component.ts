import { Component, OnInit } from "@angular/core";
// import formatter from "html-formatter";
import { HttpClient } from "@angular/common/http";
import { HttpHeaders } from "@angular/common/http";
import formatter from "html-formatter";
import { FONT } from "src/app/can/FONT";
import { SanitaizerPipe } from "src/app/sanitaizer.pipe";
import { SpeechRecognitionService } from "src/app/services/speech";

import Speech from "speak-tts"; // es6
import { OnDestroy } from "@angular/core";
const speech = new Speech(); // will throw an exception if not browser supported
if (speech.hasBrowserSupport()) {
  // returns a boolean
  console.log("speech synthesis supported");
}
@Component({
  selector: "app-can",
  templateUrl: "./can.component.html",
  styleUrls: ["./can.component.scss"]
})
export class CanComponent implements OnInit, OnDestroy {
  speechData: string;
  speech = true;
  loader: boolean;
  styler: any;
  fonter: any;
  ide: boolean;
  ids: string;
  msg = "Some msg";
  img = {
    link: "",
    class: "center",
    id: ""
  };
  anc = {
    link: "",
    class: "center",
    id: "",
    text: ""
  };
  credit = {
    username: "",
    fullname: "",
    date: ""
  };
  code = {
    text: "",
    class: "",
    id: " "
  };
  cardinfo = {
    id: "",
    title: "",
    word: "",
    blogger: "",
    version: "",
    image: ""
  };
  renderer: string;
  baseHtml: any;
  fonts = FONT;
  base: boolean;
  gas = [];
  board: boolean;
  outer: string;
  texter = "";
  copy = false;
  pred = false;
  classit = "";
  idit = "";
  sea = "";
  constructor(
    private http: HttpClient,
    private speechRecognitionService: SpeechRecognitionService
  ) {}
  ngOnDestroy() {
    this.speech = true;
    this.speechRecognitionService.DestroySpeechObject();
  }
  startSpeech(): void {
    this.speech = false;

    this.speechRecognitionService.record().subscribe(
      value => {
        this.texter = value;
        console.log(value);
        this.snacks(value);
      },
      err => {
        console.log(err);
        if (err.error === "no-speech") {
          this.speech = true;
          console.log("--restatring service--");
        }
      }
      // ,
      // () => {
      //   this.speech = true;
      //   console.log("--complete--");
      //   // this.startSpeech();
      // }
    );
  }
  ngOnInit() {
    this.baseHtml = JSON.parse(window.localStorage.getItem("power"));
    speech
      .init({
        volume: 1,
        lang: "en-GB",
        rate: 1,
        pitch: 1,
        voice: "Google UK English Male",
        splitSentences: true,
        listeners: {
          onvoiceschanged: voices => {
            // console.log("Event voiceschanged", voices);
          }
        }
      })
      .then(data => {
        // The "data" object contains the list of available voices and the voice synthesis params
        console.log("Speech is ready, voices are available", data);
      })
      .catch(e => {
        console.error("An error occured while initializing : ", e);
      });
  }
  speak(t) {
    speech
      .speak({
        text: t
      })
      .then(() => {
        console.log("Success !");
      })
      .catch(e => {
        console.error("An error occurred :", e);
      });
  }
  pause() {
    Speech.pause();
  }
  cancel() {
    Speech.cancel();
  }
  resume() {
    Speech.resume();
  }
  copyday(msg) {
    this.copy = true;
    this.msg = msg;
    setTimeout(() => {
      this.copy = false;
    }, 10000);
  }
  addTag() {
    this.gas.push(this.outer);
    this.outHtml();
  }
  removeAt(i) {
    console.log(i);
    this.gas.splice(i, 1);
    this.outHtml();
  }
  getIcon() {
    this.board = true;
    this.outer = "<i class='" + this.fonter + "'></i>";
    this.outHtml();
  }
  getSty() {
    this.board = true;
    this.outer = "<style>" + this.styler + "</style>";
    this.outHtml();
  }
  getCode() {
    this.board = true;
    this.code.text = this.code.text.replace(/(^[ \t]*\n)/gm, "");
    this.code.text = formatter.render(this.code.text);

    // this.code.text = this.code.text.replace([/</], "&lt;");
    // this.code.text = this.code.text.replace([/>/], "&gt;");
    this.outer =
      "<textarea class='code " +
      this.code.class +
      " form-control' rows='" +
      this.code.id +
      "' >" +
      this.code.text +
      "</textarea><br>";
    this.outHtml();
  }
  getImg() {
    this.board = true;
    this.outer =
      "<img style='width:50%;margin:auto;display:block;padding:10px;' src='" +
      this.img.link +
      "' class='" +
      this.img.class +
      "' id='" +
      this.img.id +
      "' /><br>";
    this.outHtml();
    this.img.link = "";
  }
  getAnc() {
    this.board = true;
    this.outer =
      "<a href='" +
      this.anc.link +
      "' class='" +
      this.anc.class +
      "' id='" +
      this.anc.id +
      "' >" +
      this.anc.text +
      "</a>";
    this.outHtml();
  }
  getCon() {
    this.board = true;
    this.outer =
      "<div class='container " +
      this.classit +
      "' id='" +
      this.idit +
      "' >" +
      this.texter +
      "</div><br>";
    this.outHtml();
  }
  getUl() {
    this.board = true;
    this.outer =
      "<ul class='list-group " +
      this.classit +
      "' id='" +
      this.idit +
      "' >" +
      this.texter +
      "</ul><br>";
    this.outHtml();
  }
  getLi() {
    this.board = true;
    this.outer =
      "<li class='list-group-item " +
      this.classit +
      "' id='" +
      this.idit +
      "' >" +
      this.texter +
      "</li> ";
    this.outHtml();
  }
  genP() {
    this.board = true;
    this.outer =
      "<p class='" +
      this.classit +
      "' id='" +
      this.idit +
      "' >" +
      this.texter +
      "</p><br>";
    this.outHtml();
  }
  lod() {
    this.loader = true;
    setTimeout(() => {
      this.loader = false;
    }, 2500);
  }
  genB() {
    this.board = true;
    this.outer = "<b>" + this.texter + "</b>";
    this.outHtml();
  }
  genSPAN() {
    this.board = true;
    this.outer =
      "<span class='" +
      this.classit +
      "' id='" +
      this.idit +
      "' >" +
      this.texter +
      "</span><br>";
    this.outHtml();
  }
  genDiv() {
    this.board = true;
    this.outer =
      "<div class='" +
      this.classit +
      "' id='" +
      this.idit +
      "'>" +
      this.texter +
      "</div><br>";
    this.outHtml();
  }
  genH(u) {
    this.board = true;
    this.outer =
      "<h" +
      u +
      " class='" +
      this.classit +
      "' id='" +
      this.idit +
      "' " +
      ">" +
      this.texter +
      "</h" +
      u +
      "><br>";
    this.outHtml();
  }
  genA() {
    this.board = true;
    this.outer =
      "<a class='" +
      this.classit +
      "' id='" +
      this.idit +
      "' href='" +
      this.texter +
      "' >" +
      this.texter +
      "</a>";
    this.outHtml();
  }
  outHtml() {
    this.base = true;
    // this.ide = true;
    // this.ids = this.makeid(6);
    this.texter = "";
    this.baseHtml = this.gas.join(" ");
    window.localStorage.setItem("power", JSON.stringify(this.baseHtml));
    this.baseHtml = formatter.render(this.baseHtml);
  }
  genBR() {
    this.board = true;
    this.outer = "<br>";
  }
  makeid(length) {
    let result = "";
    const characters =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }
  snacks(msg) {
    // Get the snackbar DIV
    const x = document.getElementById("snackbar");
    this.msg = msg;
    // Add the "show" class to DIV
    x.className = "show";

    // After 3 seconds, remove the show class from DIV
    setTimeout(function() {
      x.className = x.className.replace("show", "");
    }, 5000);
  }
}
