import { SanitaizerPipe } from './sanitaizer.pipe';

// describe('SanitaizerPipe', () => {
//   it('create an instance', () => {
//     const pipe = new SanitaizerPipe();
//     expect(pipe).toBeTruthy();
//   });
// });
