import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { SanitaizerPipe } from "src/app/sanitaizer.pipe";
import { OnDestroy } from "@angular/core";
import { SpeechRecognitionService } from "src/app/services/speech";
import { IMGLIST } from "src/app/sugar/menu";

@Component({
  selector: "app-sugar",
  templateUrl: "./sugar.component.html",
  styleUrls: ["./sugar.component.scss"]
})
export class SugarComponent implements OnInit, OnDestroy {
  msg: any;
  speech = true;
  iii: number;
  search = "";
  itemtitle: any;
  itemid: any;
  renderer: string;
  imglist = IMGLIST;
  nav = false;
  lister: any;
  box = [];
  loader = false;
  constructor(
    private http: HttpClient,
    private speechRecognitionService: SpeechRecognitionService
  ) {}
  ngOnDestroy() {
    this.speech = true;
    this.speechRecognitionService.DestroySpeechObject();
  }
  startSpeech(): void {
    this.speech = false;

    this.speechRecognitionService.record().subscribe(
      value => {
        // this.texter = value;
        console.log(value);
        this.snacks(value);
        const res = this.speechRecognitionService.findBestMatch(
          value,
          this.box
        );
        this.getRender(res["bestMatchIndex"]);
      },
      err => {
        console.log(err);
        if (err.error === "no-speech") {
          this.speech = true;
          console.log("--restatring service--");
        }
      },
      () => {
        this.speech = true;
        console.log("--complete--");
        // this.startSpeech();
      }
    );
  }
  ngOnInit() {
    this.loader = true;
    this.iii = 0;
    this.http
      .get(
        "https://raw.githubusercontent.com/creativecoderone/poster/master/menu.json"
      )
      .subscribe(
        data => {
          this.lister = data;
          // console.log(data);
          this.itemid = this.lister[0]["id"];
          this.itemtitle = this.lister[0]["title"];
          for (const key in this.lister) {
            if (this.lister.hasOwnProperty(key)) {
              const element = this.lister[key];
              this.box.push(element["title"]);
            }
          }

          this.http
            .get(
              "https://raw.githubusercontent.com/creativecoderone/poster/master/" +
                this.lister[0]["id"] +
                ".txt",
              { responseType: "text" }
            )
            .subscribe(data2 => {
              this.loader = false;
              this.renderer = data2;
            });
        },
        err => {}
      );
  }
  getRender(index) {
    // this.loader = true;
    this.itemid = this.lister[index]["id"];
    this.itemtitle = this.lister[index]["title"];
    this.http
      .get(
        "https://raw.githubusercontent.com/creativecoderone/poster/master/" +
          this.lister[index]["id"] +
          ".txt",
        { responseType: "text" }
      )
      .subscribe(
        data2 => {
          this.iii = index;
          this.loader = false;
          this.renderer = data2;
        },
        err => {}
      );
    return index;
  }
  getTitle(title) {
    console.log(title);
    let c = 0;
    for (const key in this.lister) {
      if (this.lister.hasOwnProperty(key)) {
        const element = this.lister[key];
        if (title === element["title"]) {
          this.getRender(c);
        }
        c = c + 1;
      }
    }
  }
  openNav() {
    this.nav = true;
    document.getElementById("myNav").style.width = "100%";
  }

  closeNav() {
    this.nav = false;
    document.getElementById("myNav").style.width = "0%";
  }
  ins() {
    // console.log("inc", this.iii);
    if (this.iii < this.lister.length - 1) {
      this.loader = true;
      this.iii = this.iii + 1;
      this.itemid = this.lister[this.iii]["id"];
      this.itemtitle = this.lister[this.iii]["title"];
      this.http
        .get(
          "https://raw.githubusercontent.com/creativecoderone/poster/master/" +
            this.lister[this.iii]["id"] +
            ".txt",
          { responseType: "text" }
        )
        .subscribe(
          data2 => {
            this.loader = false;
            this.snacks(this.itemtitle);
            this.renderer = data2;
          },
          err => {}
        );
    }
  }
  dis() {
    // console.log("dis", this.iii);
    if (this.iii > 0) {
      this.loader = true;
      this.iii = this.iii - 1;
      this.itemid = this.lister[this.iii]["id"];
      this.itemtitle = this.lister[this.iii]["title"];
      this.http
        .get(
          "https://raw.githubusercontent.com/creativecoderone/poster/master/" +
            this.lister[this.iii]["id"] +
            ".txt",
          { responseType: "text" }
        )
        .subscribe(
          data2 => {
            this.loader = false;
            this.snacks(this.itemtitle);
            this.renderer = data2;
          },
          err => {}
        );
    }
  }
  snacks(msg) {
    // Get the snackbar DIV
    const x = document.getElementById("snackbar");
    this.msg = msg;
    // Add the "show" class to DIV
    x.className = "show";

    // After 3 seconds, remove the show class from DIV
    setTimeout(function() {
      x.className = x.className.replace("show", "");
    }, 5000);
  }
}
