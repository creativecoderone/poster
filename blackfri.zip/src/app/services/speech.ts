import { Injectable, NgZone } from "@angular/core";
import * as _ from "lodash";
import { Observable } from "rxjs";

interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}

@Injectable()
export class SpeechRecognitionService {
  speechRecognition: any;

  constructor(private zone: NgZone) {}

  record(): Observable<string> {
    return Observable.create(observer => {
      const { webkitSpeechRecognition }: IWindow = <IWindow>window;
      this.speechRecognition = new webkitSpeechRecognition();
      this.speechRecognition.continuous = true;
      this.speechRecognition.lang = "en-us";
      this.speechRecognition.maxAlternatives = 1;

      this.speechRecognition.onresult = speech => {
        let term = "";
        if (speech.results) {
          const result = speech.results[speech.resultIndex];
          const transcript = result[0].transcript;
          if (result.isFinal) {
            if (result[0].confidence < 0.3) {
              console.log("Unrecognized result - Please try again");
            } else {
              term = _.trim(transcript);
              console.log(
                "Did you said? -> " +
                  term +
                  " , If not then say something else..."
              );
            }
          }
        }
        this.zone.run(() => {
          observer.next(term);
        });
      };

      this.speechRecognition.onerror = error => {
        observer.error(error);
      };

      this.speechRecognition.onend = () => {
        observer.complete();
      };

      this.speechRecognition.start();
      console.log("Say something - We are listening !!!");
    });
  }

  DestroySpeechObject() {
    if (this.speechRecognition) {
      this.speechRecognition.stop();
    }
  }

  compareTwoStrings(first1, second1) {
    const first = first1.replace(/\s+/g, "");
    const second = second1.replace(/\s+/g, "");

    if (!first.length && !second.length) {
      return 1;
    } // if both are empty strings
    if (!first.length || !second.length) {
      return 0;
    } // if only one is empty string
    if (first === second) {
      return 1;
    } // identical
    if (first.length === 1 && second.length === 1) {
      return 0;
    } // both are 1-letter strings
    if (first.length < 2 || second.length < 2) {
      return 0;
    } // if either is a 1-letter string

    const firstBigrams = new Map();
    for (let i = 0; i < first.length - 1; i++) {
      const bigram = first.substring(i, i + 2);
      const count = firstBigrams.has(bigram) ? firstBigrams.get(bigram) + 1 : 1;

      firstBigrams.set(bigram, count);
    }

    let intersectionSize = 0;
    for (let i = 0; i < second.length - 1; i++) {
      const bigram = second.substring(i, i + 2);
      const count = firstBigrams.has(bigram) ? firstBigrams.get(bigram) : 0;

      if (count > 0) {
        firstBigrams.set(bigram, count - 1);
        intersectionSize++;
      }
    }

    return 2.0 * intersectionSize / (first.length + second.length - 2);
  }

  findBestMatch(mainString, targetStrings) {
    const ratings = [];
    let bestMatchIndex = 0;

    for (let i = 0; i < targetStrings.length; i++) {
      const currentTargetString = targetStrings[i];
      const currentRating = this.compareTwoStrings(
        mainString,
        currentTargetString
      );
      ratings.push({ target: currentTargetString, rating: currentRating });
      if (currentRating > ratings[bestMatchIndex].rating) {
        bestMatchIndex = i;
      }
    }

    const bestMatch = ratings[bestMatchIndex];

    return { ratings, bestMatch, bestMatchIndex };
  }

  areArgsValid(mainString, targetStrings) {
    if (typeof mainString !== "string") {
      return false;
    }
    if (!Array.isArray(targetStrings)) {
      return false;
    }
    if (!targetStrings.length) {
      return false;
    }
    if (targetStrings.find(s => typeof s !== "string")) {
      return false;
    }
    return true;
  }
}
