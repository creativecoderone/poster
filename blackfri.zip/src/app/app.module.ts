import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";
import { ClipboardModule } from "ngx-clipboard";
import { CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { GoogleChartsModule } from "angular-google-charts";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { SugarComponent } from "./sugar/sugar.component";
import { CanComponent } from "./can/can.component";
import { SanitaizerPipe } from "./sanitaizer.pipe";
import { FilterPipeModule } from "ngx-filter-pipe";
import { SampleComponent } from "./sample/sample.component";
import { Ng2SearchPipeModule } from "ng2-search-filter";
import { SpeechRecognitionService } from "src/app/services/speech";
import { MugComponent } from './mug/mug.component';

@NgModule({
  declarations: [
    AppComponent,
    SugarComponent,
    CanComponent,
    SanitaizerPipe,
    SampleComponent,
    MugComponent
  ],
  imports: [
    BrowserModule,
    GoogleChartsModule,
    AppRoutingModule,
    FilterPipeModule,
    Ng2SearchPipeModule,
    HttpClientModule,
    ClipboardModule,
    FormsModule
  ],
  exports: [SanitaizerPipe],
  bootstrap: [AppComponent],
  providers: [SpeechRecognitionService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule {}
