import { Component } from "@angular/core";
import { OnDestroy } from "@angular/core";
import { OnInit } from "@angular/core";
import { environment } from "src/environments/environment";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnInit {
  cookieLinkText = "Learn more";
  cookieDismiss: "Got it";
  cookieMessage: "This website user cookies ";
  title = "Swan paper";
  caner = false;
  type = "PieChart";
  data = [
    ["Firefox", 45.0],
    ["IE", 26.8],
    ["Chrome", 12.8],
    ["Safari", 8.5],
    ["Opera", 6.2],
    ["Others", 0.7]
  ];
  columnNames = ["Browser", "Percentage"];
  options = {
    colors: ["#e0440e", "#e6693e", "#ec8f6e", "#f3b49f", "#f6c7b6"],
    is3D: true
  };
  loader = false;
  construtor() {}
  ngOnInit() {
    const cc = window as any;
    cc.cookieconsent.initialise({
      palette: {
        popup: {
          background: "#164969"
        },
        button: {
          background: "#ffe000",
          text: "#164969"
        }
      },
      theme: "classic",
      content: {
        message: "This website user cookies ensure for better experience",
        dismiss: "Got it",
        link: "Learn more",
        href: environment.Frontend + "/dataprivacy"
      }
    });
  }
  canerIt() {
    this.loader = true;
    setTimeout(() => {
      this.loader = false;
      this.caner = !this.caner;
    }, 1000);
  }
}
